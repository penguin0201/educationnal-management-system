package com.rabbiter.sms.controller.Score;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.rabbiter.sms.dto.Course;
import com.rabbiter.sms.dto.Score;
import com.rabbiter.sms.dto.User;
import com.rabbiter.sms.service.Score.ScoreService;
import com.rabbiter.sms.utils.PagingResult;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description 成绩查询控制层
 **/
@RestController
@RequestMapping("/api/sms/score")
public class ScoreController {
    @Autowired
    private ScoreService scoreService;
    @GetMapping("/getCourseList")
    public PagingResult<Course> getCourseList(@RequestParam Map<String, Object> condition,
                                              @RequestParam(required = false, name = "$limit", defaultValue = "10") Integer limit,
                                              @RequestParam(required = false, name = "$offset", defaultValue = "0") Integer offset) {
        RowBounds rowBounds = new RowBounds(offset, limit);
        return scoreService.getCourseList(rowBounds, condition);
    }
    @PostMapping("/aaa")
    private void addEntry(@RequestBody JSONArray UserScore) {
        List<Score> list = JSONObject.parseArray(UserScore.toJSONString(), Score.class);
        scoreService.addEntry(list);
    }

    @PostMapping
    public void addStudentCourse(@RequestBody Score score) {
        score.setYear(2016);
        scoreService.addStudentCourse(score);
    }

    @PostMapping("/idss")
    public void delete(@RequestBody String[] ids) {
        List<String> idsList = Arrays.asList(ids);
        scoreService.delete(idsList);
    }

    @PostMapping("/getStudentCourse")
    public List<Score> getStudentCourse(@RequestParam(required = false, name = "$limit", defaultValue = "30") Integer limit,
                                        @RequestParam(required = false, name = "$offset", defaultValue = "0") Integer offset){
        Map <String,Object> condition=new HashMap<>();
        condition.put("code",null);
        condition.put("profession",null);
        condition.put("grade",null);
        RowBounds rowBounds = new RowBounds(offset, limit);
//        PageRowBounds pageRowBounds = new PageRowBounds(rowBounds.getOffset(), rowBounds.getLimit());
//        List<User> StudentCourseList = scoreMapper.getStudentCourse(pageRowBounds, condition);
        return scoreService.getStudentCourse(rowBounds, condition);
    }

    @PostMapping("/QueryStudentCourse")
    public List<Score> getStudent(@RequestBody Map<String, Object> condition,
                                 @RequestParam(required = false, name = "$limit", defaultValue = "30") Integer limit,
                                 @RequestParam(required = false, name = "$offset", defaultValue = "0") Integer offset) {
        condition.put("profession",null);
        condition.put("grade",null);
        RowBounds rowBounds = new RowBounds(offset, limit);
        return scoreService.getStudentCourse(rowBounds, condition);
    }

    @GetMapping("/export")
    public List<Course> getExportList(@RequestParam Map<String, Object> condition) {
        return scoreService.getExportList(condition);
    }

    @GetMapping("/getUserNum")
    public List<Map<String, Object>> getUserNum(@RequestParam Map<String, Object> condition) {
        return scoreService.getUserNum(condition);
    }

    @GetMapping("/getUserTotal")
    public Map<String, Object> getUserTotal(@RequestParam Map<String, Object> condition) {
        return scoreService.getUserTotal(condition);
    }
}
