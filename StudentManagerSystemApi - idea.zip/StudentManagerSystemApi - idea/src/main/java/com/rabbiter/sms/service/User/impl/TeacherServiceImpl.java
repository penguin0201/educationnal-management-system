package com.rabbiter.sms.service.User.impl;

import com.github.pagehelper.PageRowBounds;
import com.rabbiter.sms.dao.User.TeacherMapper;
import com.rabbiter.sms.dto.User;
import com.rabbiter.sms.service.User.TeacherService;
import com.rabbiter.sms.utils.PagingResult;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Description 教师用户业务层
 * Author: rabbiter
 * Date: 2020/3/7 15:10
 **/
@Service
public class TeacherServiceImpl implements TeacherService {

  @Resource
  private TeacherMapper teacherMapper;

  @Override
  public void addTeacher(User user) {
    user.setUsername(user.getId());
    teacherMapper.addTeacher(user);
  }

  @Override
  public void delete(List<Integer> ids) {
    teacherMapper.delete(ids);
  }

  @Override
  public void update(User user) {
    teacherMapper.update(user);
  }

  @Override
  public List<User> getTeacherList(RowBounds rowBounds, Map<String, Object> condition) {
    PageRowBounds pageRowBounds = new PageRowBounds(rowBounds.getOffset(), rowBounds.getLimit());
    List<User> TeacherInfoList = teacherMapper.getTeacherList(pageRowBounds, condition);
    new PagingResult<>(TeacherInfoList, pageRowBounds.getTotal());
    return TeacherInfoList;
  }
}
