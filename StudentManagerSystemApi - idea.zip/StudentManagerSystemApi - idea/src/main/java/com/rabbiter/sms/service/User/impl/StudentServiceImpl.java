package com.rabbiter.sms.service.User.impl;

import com.github.pagehelper.PageRowBounds;
import com.rabbiter.sms.dao.Profession.ProfessionMapper;
import com.rabbiter.sms.dao.User.StudentMapper;
import com.rabbiter.sms.domain.Profession;
import com.rabbiter.sms.dto.User;
import com.rabbiter.sms.service.User.StudentService;
import com.rabbiter.sms.utils.PagingResult;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;

/**
 * Description 学生用户业务层
 * Author: rabbiter
 * Date: 2020/3/7 15:09
 **/
@Service
public class StudentServiceImpl implements StudentService {

  @Resource
  private StudentMapper studentMapper;
  @Autowired
  private ProfessionMapper professionMapper;

  @Override
  @Transactional
  public void addStudent(User user) {
    user.setUsername(user.id);
    user.setAdmissionTime("2016");
    studentMapper.addStudent(user);
  }

  @Override
  public void
  delete(List<String> ids) {
    studentMapper.delete(ids);
  }

  @Override
  public void update(User user) {
    studentMapper.update(user);
  }

  @Override
  public List<User> getStudentList(RowBounds rowBounds, Map<String, Object> condition) {
    PageRowBounds pageRowBounds = new PageRowBounds(rowBounds.getOffset(), rowBounds.getLimit());
    List<User> StudentInfoList = studentMapper.getStudentList(pageRowBounds, condition);
    new PagingResult<>(StudentInfoList, pageRowBounds.getTotal());
    return StudentInfoList;
  }

}
