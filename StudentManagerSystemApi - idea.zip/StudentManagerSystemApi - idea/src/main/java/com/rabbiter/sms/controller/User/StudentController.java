package com.rabbiter.sms.controller.User;

import com.rabbiter.sms.dto.User;
import com.rabbiter.sms.service.User.StudentService;
import com.rabbiter.sms.utils.PagingResult;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description 学生账号控制层
 **/
@RestController
@RequestMapping("/api/sms/user/student")
public class StudentController {
    @Autowired
    private StudentService studentService;

    @PostMapping
    public void addStudent(@RequestBody User user) {
        studentService.addStudent(user);
    }

    @PostMapping("/idss")
    public void delete(@RequestBody String[] ids) {
        List<String> idsList = Arrays.asList(ids);
        studentService.delete(idsList);
    }

    @PutMapping
    public void update(@RequestBody User user) {
        studentService.update(user);
    }

    @PostMapping("/getStudentList")
    public List<User> getStudentList(@RequestParam(required = false, name = "$limit", defaultValue = "8020") Integer limit,
                                     @RequestParam(required = false, name = "$offset", defaultValue = "0") Integer offset) {
        Map <String,Object> condition=new HashMap<>();
        condition.put("code",null);
        condition.put("profession",null);
        condition.put("grade",null);
        RowBounds rowBounds = new RowBounds(offset, limit);
        return studentService.getStudentList(rowBounds, condition);
    }
    @PostMapping("/getStudent")
    public List<User> getStudent(@RequestBody Map<String, Object> condition,
                                 @RequestParam(required = false, name = "$limit", defaultValue = "8020") Integer limit,
                                 @RequestParam(required = false, name = "$offset", defaultValue = "0") Integer offset) {
        condition.put("profession",null);
        condition.put("grade",null);
        RowBounds rowBounds = new RowBounds(offset, limit);
        return studentService.getStudentList(rowBounds, condition);
    }
}
