package com.rabbiter.sms.controller.Timetable;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.rabbiter.sms.domain.CourseInfo;
import com.rabbiter.sms.domain.WeekCourse;
import com.rabbiter.sms.service.Timetable.TimetableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
/**
 * Description  课程表控制层
 **/
@RestController
@RequestMapping("/api/sms/timetable")
public class TimetableController {
  @Autowired
  private TimetableService timetableService;
  /**
   * 新增、更新课程表
   */
  @PostMapping
  public void add(@RequestBody WeekCourse weekCourse)
  {
    weekCourse.setGrade("1601");
    weekCourse.setYear(2016);
    weekCourse.setTerm(1);
    weekCourse.setWeek(1);
    timetableService.add(weekCourse);
  }

  @PostMapping("/delete")
  public void delete(@RequestBody WeekCourse weekCourse)
  {
    weekCourse.setGrade("1601");
    weekCourse.setYear(2016);
    weekCourse.setTerm(1);
    weekCourse.setWeek(1);
    timetableService.delete(weekCourse);
  }
  @PostMapping("/getTimetable")
  public List<WeekCourse> getStudentList(@RequestBody Map<String,Object> condition)
  {
    condition.put("grade","1601");
    condition.put("year",2016);
    condition.put("term",1);
    condition.put("week",1);
    return timetableService.getTimetable(condition);
  }

  @GetMapping("/getTimetableByStudent")
  public List<WeekCourse> getTimetableByStudent (@RequestParam Map<String, Object> condition) {
    return timetableService.getTimetableByStudent(condition);
  }
  @GetMapping("/getTimetableByTeacher")
  public List<WeekCourse> getTimetableByTeacher (@RequestParam Map<String, Object> condition) {
    return timetableService.getTimetableByTeacher(condition);
  }
  @PostMapping("/updateCourseInfo")
  public void updateCourseInfo(@RequestBody CourseInfo courseInfo) {
    timetableService.updateCourseInfo(courseInfo);
  }

}
