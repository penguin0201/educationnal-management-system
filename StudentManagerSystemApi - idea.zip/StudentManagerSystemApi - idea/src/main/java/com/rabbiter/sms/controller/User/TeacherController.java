package com.rabbiter.sms.controller.User;

import com.rabbiter.sms.dto.User;
import com.rabbiter.sms.service.User.TeacherService;
import com.rabbiter.sms.utils.PagingResult;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description 教师账号控制层
 **/
@RestController
@RequestMapping("/api/sms/user/teacher")
public class TeacherController {
  @Autowired
  private TeacherService teacherService;

  @PostMapping
  public void addTeacher(@RequestBody User user) {
    teacherService.addTeacher(user);
  }

  @PostMapping("/idss")
  public void delete(@RequestBody Integer[] ids) {
    List<Integer> idsList = Arrays.asList(ids);
    teacherService.delete(idsList);
  }

  @PutMapping
  public void update(@RequestBody User user) {
    teacherService.update(user);
  }

  @PostMapping("/getTeacherList")
  public List<User> getTeacherList (@RequestParam(required = false, name = "$limit", defaultValue = "30") Integer limit,
                                    @RequestParam(required = false, name = "$offset", defaultValue = "0") Integer offset) {
    Map <String,Object> condition=new HashMap<>();
    condition.put("code",null);
    condition.put("profession",null);
    condition.put("grade",null);
    RowBounds rowBounds = new RowBounds(offset, limit);
    return teacherService.getTeacherList(rowBounds, condition);
  }
  @PostMapping("/getTeacher")
  public List<User> getTeacher (@RequestBody Map<String, Object> condition,
                                @RequestParam(required = false, name = "$limit", defaultValue = "30") Integer limit,
                                @RequestParam(required = false, name = "$offset", defaultValue = "0") Integer offset) {
    System.out.println(condition.get("code"));
    condition.put("profession",null);
    condition.put("grade",null);
    RowBounds rowBounds = new RowBounds(offset, limit);
    return teacherService.getTeacherList(rowBounds, condition);
  }
}
