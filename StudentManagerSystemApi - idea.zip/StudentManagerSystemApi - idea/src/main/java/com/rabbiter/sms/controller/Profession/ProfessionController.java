package com.rabbiter.sms.controller.Profession;

import com.rabbiter.sms.domain.Profession;
import com.rabbiter.sms.service.Profession.ProfessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Description 所有专业控制层
 **/
@RestController
@RequestMapping("/api/sms/profession")
public class ProfessionController {

  @Autowired
  private ProfessionService professionService;

  @PostMapping("/getProfessionList")
  private List<Profession> getProfessionList (@RequestBody Integer sb) {
    return professionService.getProfessionList();
  }
}
