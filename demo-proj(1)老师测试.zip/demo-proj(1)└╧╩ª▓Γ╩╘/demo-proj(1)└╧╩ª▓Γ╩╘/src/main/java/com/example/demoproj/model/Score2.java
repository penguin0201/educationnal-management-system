package com.example.demoproj.model;

public class Score2 extends Score{

    public String realName;

    public Score2(Score score, String realName) {
        super(score);
        this.realName = realName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    @Override
    public String toString() {
        return "Score2{" +
                "realName='" + realName + '\'' +
                '}';
    }
}
