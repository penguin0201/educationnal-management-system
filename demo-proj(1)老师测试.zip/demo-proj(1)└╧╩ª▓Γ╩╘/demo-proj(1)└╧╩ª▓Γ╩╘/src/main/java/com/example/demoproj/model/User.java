package com.example.demoproj.model;

import java.util.Date;
import java.util.Map;
/**
 * Description 登陆信息
 **/
public class User {
    /**
     * id
     */
    public String id;
    /**
     * 用户名
     */
    public String username;
    /**
     * 密码
     */
    public String password;
    /**
     * 确认密码
     */
    public String passwordAgain;
    /**
     * 真实姓名
     */
    public String realName;
    /**
     * 等级
     */
    public Integer level;
    /**
     * 学校
     */
    public String school;
    /**
     * 入学时间
     */
    public String admissiontime;
    /**
     * 电子邮箱
     */
    public String email;
    /**
     * 专业
     */
    public String profession;
    /**
     * 联系电话
     */
    public String phone;
    /**
     *  性别
     */
    public Integer sex;
    /**
     * 班级
     */
    public String grade;
    /**
     * 创建时间
     */
    public Date createtime;
    /**
     * token
     */
    public String token;
    /**
     * refreshToken
     */
    public String refreshtoken;

    public Integer state;

    public String sexStr;

    public User() {
    }
    public User(User user) {
        this.id = user.id;
        this.username = user.username;
        this.password = user.password;
        this.passwordAgain = user.passwordAgain;
        this.realName = user.realName;
        this.level = user.level;
        this.school = user.school;
        this.admissiontime = user.admissiontime;
        this.email = user.email;
        this.profession = user.profession;
        this.phone = user.phone;
        this.sex = user.sex;
        this.grade = user.grade;
        this.createtime = user.createtime;
        this.token = user.token;
        this.refreshtoken = user.refreshtoken;
        this.state = user.state;
        this.sexStr= user.sexStr;
    }

    public User(String id, String username, String password, String passwordAgain, String realName, Integer level, String school, String admissiontime, String email, String profession, String phone, Integer sex, String grade, Date createtime, String token, String refreshtoken, Integer state, String sexStr) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.passwordAgain = passwordAgain;
        this.realName = realName;
        this.level = level;
        this.school = school;
        this.admissiontime = admissiontime;
        this.email = email;
        this.profession = profession;
        this.phone = phone;
        this.sex = sex;
        this.grade = grade;
        this.createtime = createtime;
        this.token = token;
        this.refreshtoken = refreshtoken;
        this.state = state;
        this.sexStr = sexStr;
    }

    public User(String username, String password){
        this.username = username;
        this.password = password;
    }
    public User(Map map){
        this.id =getString(map,"id");
        this.username = getString(map,"username");
        this.password = getString(map,"password");
        this.passwordAgain = getString(map,"passwordAgain");
        this.realName = getString(map,"realName");
        this.level = getInteger(map,"level");
        this.school = getString(map,"school");
        this.admissiontime = getString(map,"admissiontime");
        this.email = getString(map,"email");
        this.profession = getString(map,"profession");
        this.phone = getString(map,"phone");
        this.sex = getInteger(map,"sex");
        this.grade = getString(map,"grade");
        this.token = getString(map,"token");
        this.refreshtoken = getString(map,"refreshtoken");
        this.state = getInteger(map,"state");
    }

    public static Integer getInteger(Map data, String key) {
        if(data == null)
            return null;
        Object obj = data.get(key);
        if(obj == null)
            return null;
        if(obj instanceof Integer)
            return (Integer)obj;
        String str = obj.toString();
        try {
            return (int)Double.parseDouble(str);
        }catch(Exception e) {
            return null;
        }
    }
    public static String getString(Map data,String key){
        if(data == null)
            return "";
        Object obj = data.get(key);
        if(obj == null)
            return "";
        if(obj instanceof String)
            return (String)obj;
        return obj.toString();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPasswordAgain() {
        return passwordAgain;
    }

    public void setPasswordAgain(String passwordAgain) {
        this.passwordAgain = passwordAgain;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getAdmissiontime() {
        return admissiontime;
    }

    public void setAdmissiontime(String admissiontime) {
        this.admissiontime = admissiontime;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getRefreshtoken() {
        return refreshtoken;
    }

    public void setRefreshtoken(String refreshtoken) {
        this.refreshtoken = refreshtoken;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getSexStr() {
        return sexStr;
    }

    public void setSexStr(String sexStr) {
        this.sexStr = sexStr;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", passwordAgain='" + passwordAgain + '\'' +
                ", realName='" + realName + '\'' +
                ", level=" + level +
                ", school='" + school + '\'' +
                ", admissiontime='" + admissiontime + '\'' +
                ", email='" + email + '\'' +
                ", profession='" + profession + '\'' +
                ", phone='" + phone + '\'' +
                ", sex=" + sex +
                ", grade='" + grade + '\'' +
                ", createtime=" + createtime +
                ", token='" + token + '\'' +
                ", refreshtoken='" + refreshtoken + '\'' +
                ", state=" + state +
                ", sexStr='" + sexStr + '\'' +
                '}';
    }
}
