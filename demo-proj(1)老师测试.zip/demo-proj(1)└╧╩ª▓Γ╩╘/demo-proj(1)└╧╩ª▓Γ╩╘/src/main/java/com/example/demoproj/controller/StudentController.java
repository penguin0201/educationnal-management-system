package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.User;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentController {


    @FXML
    private TableView<User> dataTableView;

    @FXML
    private TableColumn<User, String> emailColumn;

    @FXML
    private TableColumn<User, String> gradeColumn;

    @FXML
    private TableColumn<User, String> idColumn;

    @FXML
    private TextField idTextField;

    @FXML
    private TableColumn<User, String> passwordColumn;

    @FXML
    private TableColumn<User, String> phoneColumn;

    @FXML
    private TableColumn<User, String> professionColumn;

    @FXML
    private TableColumn<User, String> realNameColumn;

    @FXML
    private TextField realNameTextField;

    @FXML
    private TableColumn<User, String> schoolColumn;

    @FXML
    private TableColumn<User, String> sexColumn;

    public static List<User> studentList;

    ObservableList<User> obStudentList = FXCollections.observableArrayList();

    @FXML
    void onAddButtonClick(ActionEvent event) throws IOException {
        MainApplication.postView("addstudent.fxml");
    }

    @FXML
    void onChangeButtonClick(ActionEvent event) {
        String numName = idTextField.getText();

        if (numName == null || numName.equals("")) {
            try {
                MainApplication.postMessage("请输入学生工号");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                String[] ids = new String[1];
                ids[0] = numName;
                HttpRequestUtil.deleteStudent(ids);
                MainApplication.postView("addstudent.fxml");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void onDeleteButtonClick(ActionEvent event) throws IOException {
        String numName = idTextField.getText();
        if (numName == null || numName.equals("")) {
            try {
                MainApplication.postMessage("请输入学生工号");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                String[] ids = new String[1];
                ids[0] = numName;
                HttpRequestUtil.deleteStudent(ids);
                MainApplication.postMessage("删除成功");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        MainApplication.changeView("main-frame.fxml");
    }

    @FXML
    private void onQueryButtonClick(ActionEvent event) throws IOException {

        String realName = realNameTextField.getText();

        Map<String,Object> m = new HashMap();
        m.put("code",realName);
        studentList = HttpRequestUtil.queryStudentList(m);
        MainApplication.postView("studentQuery.fxml");
    }

    public void loadData() throws Exception{
        List<User> sList = HttpRequestUtil.getStudentList(17,0);
        obStudentList.clear();
        for (int i = 0; i < sList.size(); i++) {
            User user = sList.get(i);

            // 处理每个user对象
            if (user.sex == 0) {
                user.sexStr = "女";
            } else {user.sexStr = "男";}

            obStudentList.add(user);
        }
        dataTableView.setItems(obStudentList);
    }

    @FXML
    public void initialize() throws Exception{
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        schoolColumn.setCellValueFactory(new PropertyValueFactory<>("school"));
        realNameColumn.setCellValueFactory(new PropertyValueFactory<>("realName"));
        sexColumn.setCellValueFactory(new PropertyValueFactory<>("sexStr"));
        professionColumn.setCellValueFactory(new PropertyValueFactory<>("profession"));
        gradeColumn.setCellValueFactory(new PropertyValueFactory<>("grade"));
        loadData();
    }

}
