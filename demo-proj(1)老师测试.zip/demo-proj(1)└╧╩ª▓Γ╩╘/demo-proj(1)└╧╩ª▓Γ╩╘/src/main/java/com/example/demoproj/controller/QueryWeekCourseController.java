package com.example.demoproj.controller;

import com.example.demoproj.model.Score;
import com.example.demoproj.model.Week;
import com.example.demoproj.model.WeekCourse;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QueryWeekCourseController {

    @FXML
    private TableColumn<WeekCourse, String> fridayColumn;

    @FXML
    private TableColumn<WeekCourse, String> mondayColumn;

    @FXML
    private TableColumn<Week, Integer> numColumn;

    @FXML
    private TableView<Week> numTableView;

    @FXML
    private TableColumn< WeekCourse, String> saturdayColumn;

    @FXML
    private TableColumn<WeekCourse, String> sundayColumn;

    @FXML
    private TableView<WeekCourse> tableView;

    @FXML
    private TableColumn<WeekCourse, String> thursdayColumn;

    @FXML
    private TableColumn<WeekCourse, String> tuesdayColumn;

    @FXML
    private TableColumn<WeekCourse, String> wednesdayColumn;

    ObservableList<WeekCourse> obWCList = FXCollections.observableArrayList();
    ObservableList<Week> obNoList = FXCollections.observableArrayList();




    public void loadData() throws Exception{
        Map<String, Object> m = new HashMap<>();
        m.put("profession", QWCAcontroller.profession);
        List<WeekCourse> sList = HttpRequestUtil.getWeekCourseList(m);
        //System.out.println("opps");
        obWCList.clear();
        obNoList.clear();
        for (int i = 0; i < sList.size(); i++) {
            WeekCourse score = sList.get(i);
            Week week = new Week(i+1);
            //System.out.println(score.toString());
            obNoList.add(week);
            obWCList.add(score);
        }
        tableView.setItems(obWCList);
        numTableView.setItems(obNoList);
    }

    @FXML
    public void initialize() throws Exception{
        mondayColumn.setCellValueFactory(new PropertyValueFactory<>("monday"));
        tuesdayColumn.setCellValueFactory(new PropertyValueFactory<>("tuesday"));
        wednesdayColumn.setCellValueFactory(new PropertyValueFactory<>("wednesday"));
        thursdayColumn.setCellValueFactory(new PropertyValueFactory<>("thursday"));
        fridayColumn.setCellValueFactory(new PropertyValueFactory<>("friday"));
        saturdayColumn.setCellValueFactory(new PropertyValueFactory<>("saturday"));
        sundayColumn.setCellValueFactory(new PropertyValueFactory<>("sunday"));
        numColumn.setCellValueFactory(new PropertyValueFactory<>("no"));
        loadData();
    }
}
