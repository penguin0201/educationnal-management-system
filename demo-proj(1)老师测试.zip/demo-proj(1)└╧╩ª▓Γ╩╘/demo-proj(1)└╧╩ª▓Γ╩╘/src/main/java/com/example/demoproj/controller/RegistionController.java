package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.User;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;

public class RegistionController {

    @FXML
    private TextField passwordField;

    @FXML
    private TextField usernameField;

    @FXML
    void onRegistion(ActionEvent event) throws IOException {
        String username = usernameField.getText();
        String password = passwordField.getText();
        if( password.length() == 0  || username.length() == 0 ) {
            MainApplication.postMessage("输入为空，不能修改！");
            return;
        } else {
            User user = new User(username, password);
            String msg = HttpRequestUtil.registion(user);
            MainApplication.postMessage(msg);
        }
    }

}
