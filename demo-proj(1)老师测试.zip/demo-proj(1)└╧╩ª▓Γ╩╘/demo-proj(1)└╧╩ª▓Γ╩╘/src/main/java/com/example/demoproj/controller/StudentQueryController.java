package com.example.demoproj.controller;

import com.example.demoproj.model.User;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class StudentQueryController {

    @FXML
    private TextField emailColumn;

    @FXML
    private TextField idColumn;

    @FXML
    private TextField passwordColumn;

    @FXML
    private TextField phoneColumn;

    @FXML
    private TextField realNameColumn;

    @FXML
    private TextField schoolColumn;

    @FXML
    private TextField sexColumn;

    @FXML
    private TextField gradeColumn;

    @FXML
    private TextField professionColumn;

    public void initialize() throws Exception{
        User user = StudentController.studentList.get(0);
        emailColumn.setText(user.email);
        idColumn.setText(user.id);
        passwordColumn.setText(user.password);
        phoneColumn.setText(user.phone);
        schoolColumn.setText(user.school);
        realNameColumn.setText(user.realName);
        gradeColumn.setText(user.grade);
        professionColumn.setText(user.profession);
        if (user.sex == 0) sexColumn.setText("女");
        else sexColumn.setText("男");
    }
}
