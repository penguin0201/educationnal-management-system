package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.Course;
import com.example.demoproj.model.Score;
import com.example.demoproj.model.User;
import com.example.demoproj.request.HttpRequestUtil;
import com.example.demoproj.util.CourseStringConverter;
import com.example.demoproj.util.StudentStringConverter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class AddscoreController {

    @FXML
    private ChoiceBox<Course> courseBox;

    @FXML
    private TextField creditsField;

    @FXML
    private ChoiceBox<User> studentBox;

    @FXML
    private TextField pointField;

    @FXML
    private TextField scoreField;

    @FXML
    private TextField termField;

    public void initialize() {
        courseBox.getItems().addAll(HttpRequestUtil.getCourseList(0,17));
        courseBox.setConverter(new CourseStringConverter());
        studentBox.getItems().addAll(HttpRequestUtil.getStudentList(0,17));
        studentBox.setConverter(new StudentStringConverter());
    }
    @FXML
    void onAddCourse(ActionEvent event) throws IOException {
        Map<String,Object> map = new HashMap<>();
        map.put("courseId",courseBox.getValue().id);
        map.put("credits",creditsField.getText());
        map.put("name",courseBox.getValue().name);
        map.put("point",pointField.getText());
        map.put("score",scoreField.getText());
        map.put("studentId",studentBox.getValue().id);
        map.put("term",termField.getText());
        Score score = new Score(map);
        HttpRequestUtil.addScore(score);
        MainApplication.changeView("main-frame.fxml");
    }

}
