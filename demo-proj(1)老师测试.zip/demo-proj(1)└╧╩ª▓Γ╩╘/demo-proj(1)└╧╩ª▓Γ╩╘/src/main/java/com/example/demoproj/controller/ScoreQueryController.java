package com.example.demoproj.controller;

import com.example.demoproj.model.Score;
import com.example.demoproj.model.Score2;
import com.example.demoproj.model.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class ScoreQueryController {
    @FXML
    private TableColumn<Score2, String> courseIdColumn1;

    @FXML
    private TableColumn<Score2, String> creditsColumn1;

    @FXML
    private TableView<Score2> dataTableView;

    @FXML
    private TableColumn<Score2, String> nameColumn1;

    @FXML
    private TableColumn<Score2, String> pointColumn1;

    @FXML
    private TableColumn<Score2, String> realNameColumn1;

    @FXML
    private TableColumn<Score2, Integer> scoreColumn1;

    @FXML
    private TableColumn<Score2, String> studentIdColumn1;

    @FXML
    private TableColumn<Score2, Integer> termColumn1;

    String realName;

    ObservableList<Score2> obScore2List = FXCollections.observableArrayList();

    public void initialize() throws Exception{
        courseIdColumn1.setCellValueFactory(new PropertyValueFactory<>("courseId"));
        creditsColumn1.setCellValueFactory(new PropertyValueFactory<>("credits"));
        nameColumn1.setCellValueFactory(new PropertyValueFactory<>("name"));
        pointColumn1.setCellValueFactory(new PropertyValueFactory<>("point"));
        scoreColumn1.setCellValueFactory(new PropertyValueFactory<>("score"));
        studentIdColumn1.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        termColumn1.setCellValueFactory(new PropertyValueFactory<>("term"));
        realNameColumn1.setCellValueFactory(new PropertyValueFactory<>("realName"));
        for (Score score : ScoreController.scoreList) {
            realName = ScoreController.students2.get(score.studentId);
            Score2 score2 = new Score2(score,realName);
            obScore2List.add(score2);
        }
        dataTableView.setItems(obScore2List);
    }
}
