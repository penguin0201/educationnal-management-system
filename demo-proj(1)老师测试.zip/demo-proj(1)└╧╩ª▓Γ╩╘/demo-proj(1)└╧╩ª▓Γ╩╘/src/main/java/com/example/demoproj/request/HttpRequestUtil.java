package com.example.demoproj.request;


import com.example.demoproj.model.*;
import com.google.gson.Gson;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * HttpRequestUtil 后台请求实例程序，主要实践向后台发送请求的方法
 *  static boolean isLocal 业务处理程序实现方式 false java-server实现 前端程序通过下面的方法把数据发送后台程序，后台返回前端需要的数据，true 本地方式 业务处理 在SQLiteJDBC 实现
 *  String serverUrl = "http://localhost:9090" 后台服务的机器地址和端口号
 */
public class HttpRequestUtil {
    public static boolean isLocal = false;
    private static Gson gson = new Gson();
    private static HttpClient client = HttpClient.newHttpClient();
    public static String serverUrl = "http://localhost:9121";
//    public static String serverUrl = "http://202.194.14.120:9090";

    /**
     * String login(LoginRequest request)  用户登录请求实现
     *
     * @param /request username 登录账号 password 登录密码
     * @return 返回null 登录成功 AppStore注册登录账号信息 非空，登录错误信息
     */

    public static String login(Map condition) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/login"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(condition)))
                .headers("Content-Type", "application/json")
                .build();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            //System.out.println(loginMap.get("username"));

            Boolean isLogin = gson.fromJson(response.body(), Boolean.class);
            if (isLogin == true) {
                //Map<String,Object> map = gson.fromJson(response.body(), Map.class);
                //AppStore.setJwt(map);
                return null;
            } else if (response.statusCode() == 401) {
                return "用户名或密码不存在！";
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "登录失败";
    }

    public static String upimage(Map imageMap){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/upload/getHeadImg"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(imageMap)))
                .headers("Content-Type", "application/json")
                .build();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            String imageurl = gson.fromJson(gson.toJson(response.body()), String.class);
            return imageurl;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static String changePassword(Map condition) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/edit/password"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(condition)))
                .headers("Content-Type", "application/json")
                .build();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            Boolean isChange = gson.fromJson(response.body(), Boolean.class);
            if (isChange == true) {
                return "修改成功！";
            } else {
                return "修改失败！";
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "修改是失败";
    }

    public static String registion(User user) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/admin"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(user)))
                .headers("Content-Type", "application/json")
                .build();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            Boolean isRe = gson.fromJson(response.body(), Boolean.class);
            if (isRe == true) {
                return "注册成功！";
            } else {
                return "注册失败！";
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "注册是失败";
    }

    public static List<User> getTeacherList (int limit,int offset) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/teacher/getTeacherList"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(limit)))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(offset)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<User> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new User((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void addTeacher(User user) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/teacher"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(user)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("添加成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static void deleteTeacher(Integer[] id) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/teacher/idss"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(id)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("删除成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static List<User> queryTeacherList (Map m) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/teacher/getTeacher"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(m)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<User> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new User((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<User> getStudentList (int limit,int offset) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/student/getStudentList"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(limit)))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(offset)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<User> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new User((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void addStudent(User user) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/student"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(user)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("添加成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static void deleteStudent(String[] id) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/student/idss"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(id)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("删除成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static List<User> queryStudentList (Map m) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/user/student/getStudent"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(m)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<User> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new User((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Course> getCourseList (int limit,int offset) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/course/getCourseList"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(limit)))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(offset)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<Course> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new Course((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void addCourse(com.example.demoproj.model.Course course) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/course"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(course)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("添加成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static void deleteCourse(String[] id) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/course/idss"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(id)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("删除成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static List<Course> queryCourseList (Map m) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/course/getCourse"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(m)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<Course> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new Course((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Profession> getProfessionList () {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/profession/getProfessionList"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(1)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<Profession> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new Profession((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Score> getScoreList (int limit, int offset) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/score/getStudentCourse"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(limit)))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(offset)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<Score> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new Score((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void addScore(Score score) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/score"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(score)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("添加成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static void deleteScore(String[] id) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/score/idss"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(id)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("删除成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static List<Score> queryScoreList (Map m) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/score/QueryStudentCourse"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(m)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<Score> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new Score((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void addWeekCourse(WeekCourse weekCourse) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/timetable"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(weekCourse)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("添加成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void deleteWeekCourse(WeekCourse weekCourse) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/timetable/delete"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(weekCourse)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                System.out.println("删除成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static List<WeekCourse> getWeekCourseList (Map m) {
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/api/sms/timetable/getTimetable"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(m)))
                .headers("Content-Type", "application/json")
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("response.statusCode====" + response.statusCode());
            if(response.statusCode() == 200) {
                List list = gson.fromJson(response.body(),List.class);
                //System.out.println(list.get(0));
                List<WeekCourse> rList = new ArrayList<>();
                for(int i = 0; i < list.size();i++) {
                    rList.add(new WeekCourse((Map) list.get(i)));
                    //System.out.println(rList);
                }
                return rList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }
}

