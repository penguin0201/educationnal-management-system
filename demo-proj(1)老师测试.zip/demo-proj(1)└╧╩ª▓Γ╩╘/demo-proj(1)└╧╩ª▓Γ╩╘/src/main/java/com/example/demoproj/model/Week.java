package com.example.demoproj.model;

public class Week {
    public Integer no;
    public Week(Integer no) {
        this.no = no;
    }

    public Integer getNo() {
        return no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    @Override
    public String toString() {
        return "Week{" +
                "no=" + no +
                '}';
    }
}
