package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.WeekCourse;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;

public class DeleteWeekCourseController {

    @FXML
    private TextField professionField;

    @FXML
    void onDelete(ActionEvent event) throws IOException {
        String profession = professionField.getText();
        if (profession == null || profession.equals("")) {
            try {
                MainApplication.postMessage("请输入专业");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            WeekCourse weekCourse = new WeekCourse(profession);
            HttpRequestUtil.deleteWeekCourse(weekCourse);
            MainApplication.postMessage("删除成功");
        }
    }

}
