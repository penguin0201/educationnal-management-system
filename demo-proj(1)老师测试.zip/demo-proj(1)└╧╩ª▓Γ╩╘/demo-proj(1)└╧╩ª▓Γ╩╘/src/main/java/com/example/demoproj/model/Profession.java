package com.example.demoproj.model;

import java.util.Map;

/**
 * Description 专业实体类
 **/
public class Profession {
  /**
   * 专业id
   */
  public Integer id;
  /**
   * 专业名
   */
  public String name;

  public Profession() {
  }

  public Profession(Integer id, String name) {
    this.id = id;
    this.name = name;
  }
  public Profession(Map m) {
    this.name = getString(m,"name");
    this.id = getInteger(m,"id");
  }
  public static Integer getInteger(Map data, String key) {
    if(data == null)
      return null;
    Object obj = data.get(key);
    if(obj == null)
      return null;
    if(obj instanceof Integer)
      return (Integer)obj;
    String str = obj.toString();
    try {
      return (int)Double.parseDouble(str);
    }catch(Exception e) {
      return null;
    }
  }
  public static Double getDouble(Map data, String key) {
    if(data == null)
      return null;
    Object obj = data.get(key);
    if(obj == null)
      return null;
    if(obj instanceof Double)
      return (Double)obj;
    String str = obj.toString();
    try {
      return (Double) Double.parseDouble(str);
    }catch(Exception e) {
      return null;
    }
  }
  public static String getString(Map data,String key){
    if(data == null)
      return "";
    Object obj = data.get(key);
    if(obj == null)
      return "";
    if(obj instanceof String)
      return (String)obj;
    return obj.toString();
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return "Profession{" +
            "id=" + id +
            ", name='" + name + '\'' +
            '}';
  }
}
