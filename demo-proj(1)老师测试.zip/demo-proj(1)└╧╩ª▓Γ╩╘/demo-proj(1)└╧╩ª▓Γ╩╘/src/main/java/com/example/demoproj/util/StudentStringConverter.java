package com.example.demoproj.util;

import com.example.demoproj.model.User;
import javafx.util.StringConverter;

public class StudentStringConverter extends StringConverter<User> {
    @Override
    public String toString(User user) {
        return user == null ? null : user.realName;
    }

    @Override
    public User fromString(String s) {
        return null;
    }
}
