package com.example.demoproj.model;

import java.util.Date;
import java.util.Map;

/**
 * Description 课程信息实体类
 **/
public class Course {
  /**
   * id
   */
  public String id;

  /**
   * 课程名
   */
  public String name;
  /**
   * 学分
   */
  public Double credits;
  /**
   * 满分
   */
  public Integer score;
  /**
   * 课时
   */
  public Integer number;
  /**
   * 届时
   */
  public Integer year;
  /**
   * 学期
   */
  public Integer term;
  /**
   * 类型 1： 必修  2：选修
   */
  public Integer type;
  /**
   * 专业
   */
  public String profession;
  /**
   * 班级
   */
  public String grade;
  /**
   * 姓名
   */
  public String realName;
  /**
   * 学号
   */
  public String no;
  /**
   * 学生账号
   */
  public String studentId;
  /**
   * 查询的学生绩点
   */
  public String pointByUser;
  /**
   * 查询的学生分数
   */
  public String scoreByUser;
  /**
   * 查询的学生学分
   */
  public String creditsByUser;
  /**
   * 周数 start
   */
  public Integer start;
  /**
   * 周数 end
   */
  public Integer end;
  /**
   * 教室
   */
  public String room;
  /**
   * 创建时间
   */
  public Date createTime;

  public String typeStr;

  public Course() {
  }

  public Course(String id, String name, Double credits, Integer score, Integer number, Integer year, Integer term, Integer type, String profession, String grade, String realName, String no, String studentId, String pointByUser, String scoreByUser, String creditsByUser, Integer start, Integer end, String room, Date createTime, String typeStr) {
    this.id = id;
    this.name = name;
    this.credits = credits;
    this.score = score;
    this.number = number;
    this.year = year;
    this.term = term;
    this.type = type;
    this.profession = profession;
    this.grade = grade;
    this.realName = realName;
    this.no = no;
    this.studentId = studentId;
    this.pointByUser = pointByUser;
    this.scoreByUser = scoreByUser;
    this.creditsByUser = creditsByUser;
    this.start = start;
    this.end = end;
    this.room = room;
    this.createTime = createTime;
    this.typeStr = typeStr;
  }

  public Course(Map map) {
    this.id = getString(map, "id");
    this.name = getString(map, "name");
    this.credits = getDouble(map, "credits");
    this.score = getInteger(map, "score");
    this.number = getInteger(map, "number");
    this.year = getInteger(map, "year");
    this.term = getInteger(map, "term");
    this.type = getInteger(map, "type");
    this.grade = getString(map, "grade");
    this.profession = getString(map, "profession");
    this.realName = getString(map, "realName");
    this.no = getString(map, "no");
    this.studentId = getString(map, "studentId");
    this.pointByUser = getString(map, "pointByUser");
    this.creditsByUser = getString(map, "creditsByUser");
    this.start = getInteger(map, "start");
    this.end = getInteger(map, "end");
    this.room = getString(map, "room");
    this.typeStr=getString(map,"typeStr");
  }

  public static Integer getInteger(Map data, String key) {
    if (data == null)
      return null;
    Object obj = data.get(key);
    if (obj == null)
      return null;
    if (obj instanceof Integer)
      return (Integer) obj;
    String str = obj.toString();
    try {
      return (int) Double.parseDouble(str);
    } catch (Exception e) {
      return null;
    }
  }

  public static Double getDouble(Map data, String key) {
    if (data == null)
      return null;
    Object obj = data.get(key);
    if (obj == null)
      return null;
    if (obj instanceof Double)
      return (Double) obj;
    String str = obj.toString();
    try {
      return (Double) Double.parseDouble(str);
    } catch (Exception e) {
      return null;
    }
  }

  public static String getString(Map data, String key) {
    if (data == null)
      return "";
    Object obj = data.get(key);
    if (obj == null)
      return "";
    if (obj instanceof String)
      return (String) obj;
    return obj.toString();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Double getCredits() {
    return credits;
  }

  public void setCredits(Double credits) {
    this.credits = credits;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public Integer getNumber() {
    return number;
  }

  public void setNumber(Integer number) {
    this.number = number;
  }

  public Integer getYear() {
    return year;
  }

  public void setYear(Integer year) {
    this.year = year;
  }

  public Integer getTerm() {
    return term;
  }

  public void setTerm(Integer term) {
    this.term = term;
  }

  public Integer getType() {
    return type;
  }

  public void setType(Integer type) {
    this.type = type;
  }

  public String getProfession() {
    return profession;
  }

  public void setProfession(String profession) {
    this.profession = profession;
  }

  public String getGrade() {
    return grade;
  }

  public void setGrade(String grade) {
    this.grade = grade;
  }

  public String getRealName() {
    return realName;
  }

  public void setRealName(String realName) {
    this.realName = realName;
  }

  public String getNo() {
    return no;
  }

  public void setNo(String no) {
    this.no = no;
  }

  public String getStudentId() {
    return studentId;
  }

  public void setStudentId(String studentId) {
    this.studentId = studentId;
  }

  public String getPointByUser() {
    return pointByUser;
  }

  public void setPointByUser(String pointByUser) {
    this.pointByUser = pointByUser;
  }

  public String getScoreByUser() {
    return scoreByUser;
  }

  public void setScoreByUser(String scoreByUser) {
    this.scoreByUser = scoreByUser;
  }

  public String getCreditsByUser() {
    return creditsByUser;
  }

  public void setCreditsByUser(String creditsByUser) {
    this.creditsByUser = creditsByUser;
  }

  public Integer getStart() {
    return start;
  }

  public void setStart(Integer start) {
    this.start = start;
  }

  public Integer getEnd() {
    return end;
  }

  public void setEnd(Integer end) {
    this.end = end;
  }

  public String getRoom() {
    return room;
  }

  public void setRoom(String room) {
    this.room = room;
  }

  public Date getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  public String getTypeStr() {
    return typeStr;
  }

  public void setTypeStr(String typeStr) {
    this.typeStr = typeStr;
  }

  @Override
  public String toString() {
    return "Course{" +
            "id='" + id + '\'' +
            ", name='" + name + '\'' +
            ", credits=" + credits +
            ", score=" + score +
            ", number=" + number +
            ", year=" + year +
            ", term=" + term +
            ", type=" + type +
            ", profession='" + profession + '\'' +
            ", grade='" + grade + '\'' +
            ", realName='" + realName + '\'' +
            ", no='" + no + '\'' +
            ", studentId='" + studentId + '\'' +
            ", pointByUser='" + pointByUser + '\'' +
            ", scoreByUser='" + scoreByUser + '\'' +
            ", creditsByUser='" + creditsByUser + '\'' +
            ", start=" + start +
            ", end=" + end +
            ", room='" + room + '\'' +
            ", createTime=" + createTime +
            ", typeStr='" + typeStr + '\'' +
            '}';
  }
}
