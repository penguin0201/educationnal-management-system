package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.Course;
import com.example.demoproj.model.Profession;
import com.example.demoproj.model.WeekCourse;
import com.example.demoproj.request.HttpRequestUtil;
import com.example.demoproj.util.CourseStringConverter;
import com.example.demoproj.util.ProfessionStringConverter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.List;

public class AddWeekCourseController {


    @FXML
    private ChoiceBox<Course> fridayBox;

    @FXML
    private ChoiceBox<Course> mondayBox;

    @FXML
    private ChoiceBox<Course> saturdayBox;

    @FXML
    private ChoiceBox<Course> sundayBox;

    @FXML
    private ChoiceBox<Course> thursdayBox;

    @FXML
    private ChoiceBox<Course> tuesdayBox;

    @FXML
    private ChoiceBox<Course> wednesdayBox;
    @FXML
    private ChoiceBox<Profession> professionBox;


    public void initialize() {
        List<Course> courseList = HttpRequestUtil.getCourseList(0,17);
        mondayBox.getItems().addAll(courseList);
        mondayBox.setConverter(new CourseStringConverter());
        tuesdayBox.getItems().addAll(courseList);
        tuesdayBox.setConverter(new CourseStringConverter());
        wednesdayBox.getItems().addAll(courseList);
        wednesdayBox.setConverter(new CourseStringConverter());
        thursdayBox.getItems().addAll(courseList);
        thursdayBox.setConverter(new CourseStringConverter());
        fridayBox.getItems().addAll(courseList);
        fridayBox.setConverter(new CourseStringConverter());
        saturdayBox.getItems().addAll(courseList);
        saturdayBox.setConverter(new CourseStringConverter());
        sundayBox.getItems().addAll(courseList);
        sundayBox.setConverter(new CourseStringConverter());
        List<Profession> professionList = HttpRequestUtil.getProfessionList();
        professionBox.getItems().addAll(professionList);
        professionBox.setConverter(new ProfessionStringConverter());
    }
    @FXML
    void onAddButtonClick(ActionEvent event) throws IOException {
        String monday = mondayBox.getValue().name;
        String tuesday = tuesdayBox.getValue().name;
        String wednesday = wednesdayBox.getValue().name;
        String thursday = thursdayBox.getValue().name;
        String friday = fridayBox.getValue().name;
        String saturday = saturdayBox.getValue().name;
        String sunday = sundayBox.getValue().name;
        String profession = professionBox.getValue().name;
        WeekCourse weekCourse = new WeekCourse(monday,tuesday,wednesday,thursday,friday,saturday,sunday,profession);
        HttpRequestUtil.addWeekCourse(weekCourse);
        MainApplication.postMessage("添加成功");
    }

}
