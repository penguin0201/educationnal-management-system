package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;

public class ChooseController {

    @FXML
    void onA(ActionEvent event) throws IOException {
        MainApplication.changeView("login.fxml");
    }

    @FXML
    void onB(ActionEvent event) throws IOException {
        MainApplication.changeView("login.fxml");
    }

    @FXML
    void onC(ActionEvent event) throws IOException {
        MainApplication.changeView("login.fxml");
    }

}
