package com.example.demoproj.util;

import com.example.demoproj.model.Profession;
import javafx.util.StringConverter;

public class ProfessionStringConverter extends StringConverter<Profession> {
    @Override
    public String toString(Profession profession) {
        return profession == null ? null : profession.name;
    }

    @Override
    public Profession fromString(String s) {
        return null;
    }
}
