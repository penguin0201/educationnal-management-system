package com.example.demoproj.controller;

import com.example.demoproj.model.Course;
import com.example.demoproj.model.Profession;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class ProfessionController {

    @FXML
    private TableColumn<Profession, Integer> idColumn;

    @FXML
    private TableColumn<Profession, String> nameColumn;
    @FXML
    private TableView<Profession> dataTableView;

    public static List<Profession> professionList;

    ObservableList<Profession> obProfessionList = FXCollections.observableArrayList();

    public void loadData() throws Exception{
        List<Profession> sList = HttpRequestUtil.getProfessionList();
        obProfessionList.clear();
        for (int i = 0; i < sList.size(); i++) {
            Profession profession = sList.get(i);

            obProfessionList.add(profession);
        }
        dataTableView.setItems(obProfessionList);
    }

    @FXML
    public void initialize() throws Exception{
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        loadData();
    }
}
