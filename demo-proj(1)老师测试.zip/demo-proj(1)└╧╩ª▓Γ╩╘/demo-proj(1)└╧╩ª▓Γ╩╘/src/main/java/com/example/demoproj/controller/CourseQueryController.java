package com.example.demoproj.controller;

import com.example.demoproj.model.Course;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class CourseQueryController {

    @FXML
    private TextField creditsColumn;

    @FXML
    private TextField idColumn;

    @FXML
    private TextField nameColumn;

    @FXML
    private TextField numberColumn;

    @FXML
    private TextField professionColumn;

    @FXML
    private TextField scoreColumn;

    @FXML
    private TextField termColumn;

    @FXML
    private TextField typeColumn;

    public void initialize() throws Exception{
        Course course = CourseController.courseList.get(0);
        idColumn.setText(course.id);
        professionColumn.setText(course.profession);
        nameColumn.setText(course.name);
        termColumn.setText(String.valueOf(course.term));
        scoreColumn.setText(String.valueOf(course.score));
        numberColumn.setText(String.valueOf(course.number));
        creditsColumn.setText(String.valueOf(course.credits));
        if (course.type == 0) typeColumn.setText("选修");
        else typeColumn.setText("必修");
    }
}
