package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;

public class QWCAcontroller {

    @FXML
    private TextField professionField;

    public static String profession;

    @FXML
    void onQuery(ActionEvent event) throws IOException {
        profession = professionField.getText();
        MainApplication.postView("queryweekcourse.fxml");
    }

}
