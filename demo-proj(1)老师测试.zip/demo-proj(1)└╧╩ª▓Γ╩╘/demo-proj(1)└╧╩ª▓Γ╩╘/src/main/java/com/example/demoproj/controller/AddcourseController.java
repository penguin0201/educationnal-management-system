package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.Course;
import com.example.demoproj.model.Profession;
import com.example.demoproj.model.User;
import com.example.demoproj.request.HttpRequestUtil;
import com.example.demoproj.util.ProfessionStringConverter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class AddcourseController implements Initializable {

    @FXML
    private TextField creditsField;

    @FXML
    private TextField idField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField numberField;

    @FXML
    private ChoiceBox<Profession> professionBox;

    @FXML
    private TextField scoreField;

    @FXML
    private TextField termField;

    @FXML
    private ChoiceBox<String> typeField;
    private String[] type = { "选修", "必修" };

    @FXML
    void onAddCourse(ActionEvent event) throws IOException {
        Map<String,Object> map = new HashMap<>();
        map.put("id",idField.getText());
        map.put("profession",professionBox.getSelectionModel().getSelectedItem().name);
        map.put("name",nameField.getText());
        map.put("term",termField.getText());
        map.put("score",scoreField.getText());
        map.put("number",numberField.getText());
        map.put("credits",creditsField.getText());
        map.put("type",gettype(event));
        Course course = new Course(map);
        HttpRequestUtil.addCourse(course);
        MainApplication.changeView("main-frame.fxml");
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        typeField.getItems().addAll(type);
        typeField.getSelectionModel().select(1);
        typeField.setOnAction(this::gettype);
        List<Profession> professionList = HttpRequestUtil.getProfessionList();
        professionBox.setConverter(new ProfessionStringConverter());
        professionBox.getItems().addAll(professionList);
    }
    private int gettype(ActionEvent event) {
        return typeField.getSelectionModel().getSelectedIndex();
    }
}
