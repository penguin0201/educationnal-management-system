package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.User;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherController {

    @FXML
    private TableView<User> dataTableView;

    @FXML
    private TableColumn<User, String> emailColumn;

    @FXML
    private TableColumn<User, String> idColumn;

    @FXML
    private TextField numNameTextField;
    @FXML
    private TextField realNameTextField;

    @FXML
    private TableColumn<User, String> passwordColumn;

    @FXML
    private TableColumn<User, String> phoneColumn;

    @FXML
    private TableColumn<User, String> professionColumn;

    @FXML
    private TableColumn<User, String> sexColumn;

    @FXML
    private TableColumn<User, String> usernameColumn;

    public static List<User> teacherList;

    ObservableList<User> obTeacherList = FXCollections.observableArrayList();
    @FXML
    private void onAddButtonClick(ActionEvent event) throws Exception {
        MainApplication.postView("addteacher.fxml");
    }

    @FXML
    private void onChangeButtonClick(ActionEvent event) {

        String numName = numNameTextField.getText();

        if (numName == null || numName.equals("")) {
            try {
                MainApplication.postMessage("请输入教师工号");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                Integer[] ids = new Integer[1];
                int id = Integer.parseInt(numName);
                ids[0] = id;
                HttpRequestUtil.deleteTeacher(ids);
                MainApplication.postView("addteacher.fxml");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void onDeleteButtonClick(ActionEvent event) throws IOException {
        String numName = numNameTextField.getText();
        if (numName == null || numName.equals("")) {
            try {
                MainApplication.postMessage("请输入教师工号");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                Integer[] ids = new Integer[1];
                int id = Integer.parseInt(numName);
                ids[0] = id;
                HttpRequestUtil.deleteTeacher(ids);
                MainApplication.postMessage("删除成功");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        MainApplication.changeView("main-frame.fxml");
    }

    @FXML
    private void onQueryButtonClick(ActionEvent event) throws IOException {

        String realName = realNameTextField.getText();

        Map<String,Object> m = new HashMap();
        m.put("code",realName);
        teacherList = HttpRequestUtil.queryTeacherList(m);
        MainApplication.postView("teacherQuery.fxml");
    }

    public void loadData() throws Exception{
        List<User> teacherList = HttpRequestUtil.getTeacherList(17,0);
        obTeacherList.clear();
//        for (User teacher : teacherList) {
//            teacher.setSexStr();
//            obTeacherList.add(teacher);
//        }
        for (int i = 0; i < teacherList.size(); i++) {
            User user = teacherList.get(i);

            // 处理每个user对象
            if (user.sex == 0) {
                user.sexStr = "女";
            } else {user.sexStr = "男";}

            obTeacherList.add(user);
        }
        dataTableView.setItems(obTeacherList);
    }

    @FXML
    public void initialize() throws Exception{
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        professionColumn.setCellValueFactory(new PropertyValueFactory<>("school"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("realName"));
        sexColumn.setCellValueFactory(new PropertyValueFactory<>("sexStr"));
        loadData();
//        List<User> teacherList = HttpRequestUtil.getTeacherList(100,0);
//        if (teacherList instanceof List<User>) System.out.println(teacherList);
    }

}
