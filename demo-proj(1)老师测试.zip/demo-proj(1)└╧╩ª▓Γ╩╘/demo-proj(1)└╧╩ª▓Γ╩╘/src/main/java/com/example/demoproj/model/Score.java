package com.example.demoproj.model;

import java.util.Map;

/**
 * Description 分数信息实体类
 **/
public class Score {
  /**
   * id
   */
  public Long id;
  /**
   * 用户名
   */
  public String username;
  /**
   * 课程名
   */
  public String name;
  /**
   * 分数
   */
  public String scoreByUser;
  /**
   * 绩点
   */
  public String pointByUser;
  /**
   * 学分
   */
  public String creditsByUser;
  /**
   * 总分
   */
  public Integer score;
  /**
   * 绩点
   */
  public String point;

  public Score(Long id, String username, String name, String scoreByUser, String pointByUser, String creditsByUser, Integer score, String point, String credits, Integer term, Integer year, String no, String studentId, String courseId) {
    this.id = id;
    this.username = username;
    this.name = name;
    this.scoreByUser = scoreByUser;
    this.pointByUser = pointByUser;
    this.creditsByUser = creditsByUser;
    this.score = score;
    this.point = point;
    this.credits = credits;
    this.term = term;
    this.year = year;
    this.no = no;
    this.studentId = studentId;
    this.courseId = courseId;
  }
  public Score(Map data) {
    this.id = getLong(data,"id");
    this.username = getString(data,"username");
    this.name = getString(data,"name");
    this.scoreByUser = getString(data,"scoreByUser");
    this.pointByUser = getString(data,"pointByUser");
    this.creditsByUser = getString(data,"creditsByUser");
    this.score = getInteger(data,"score");
    this.point = getString(data,"point");
    this.credits = getString(data,"credits");
    this.term = getInteger(data,"term");
    this.year = getInteger(data,"year");
    this.no = getString(data,"no");
    this.studentId = getString(data,"studentId");
    this.courseId = getString(data,"courseId");
  }
  public Score(Score score){
    this.id = score.id;
    this.username = score.username;
    this.name = score.name;
    this.scoreByUser = score.scoreByUser;
    this.pointByUser = score.pointByUser;
    this.creditsByUser = score.creditsByUser;
    this.score = score.score;
    this.point = score.point;
    this.credits = score.credits;
    this.term = score.term;
    this.year = score.year;
    this.no = score.no;
    this.studentId = score.studentId;
    this.courseId = score.courseId;
  }


  public static Integer getInteger(Map data, String key) {
    if(data == null)
      return null;
    Object obj = data.get(key);
    if(obj == null)
      return null;
    if(obj instanceof Integer)
      return (Integer)obj;
    String str = obj.toString();
    try {
      return (int)Double.parseDouble(str);
    }catch(Exception e) {
      return null;
    }
  }
  public static String getString(Map data,String key){
    if(data == null)
      return "";
    Object obj = data.get(key);
    if(obj == null)
      return "";
    if(obj instanceof String)
      return (String)obj;
    return obj.toString();
  }
    public static Long getLong(Map data, String key) {
        if(data == null)
          return null;
        Object obj = data.get(key);
        if(obj == null)
          return null;
        if(obj instanceof Long)
          return (Long)obj;
        String str = obj.toString();
        try {
          return (long)Double.parseDouble(str);
        }catch(Exception e) {
          return null;
        }
    }
  /**
   * 学分
   */
  public String credits;
  /**
   * 学期
   */
  public Integer term;
  /**
   * 届时
   */
  public Integer year;
  /**
   * 学号
   */
  public String no;
  /**
   * 学生账号id
   */
  public String studentId;
  /**
   * 课程id
   */
  public String courseId;

  public Score() {
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getScoreByUser() {
    return scoreByUser;
  }

  public void setScoreByUser(String scoreByUser) {
    this.scoreByUser = scoreByUser;
  }

  public String getPointByUser() {
    return pointByUser;
  }

  public void setPointByUser(String pointByUser) {
    this.pointByUser = pointByUser;
  }

  public String getCreditsByUser() {
    return creditsByUser;
  }

  public void setCreditsByUser(String creditsByUser) {
    this.creditsByUser = creditsByUser;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public String getCredits() {
    return credits;
  }

  public void setCredits(String credits) {
    this.credits = credits;
  }

  public String getPoint() {
    return point;
  }

  public void setPoint(String point) {
    this.point = point;
  }

  public Integer getTerm() {
    return term;
  }

  public void setTerm(Integer term) {
    this.term = term;
  }

  public Integer getYear() {
    return year;
  }

  public void setYear(Integer year) {
    this.year = year;
  }

  public String getNo() {
    return no;
  }

  public void setNo(String no) {
    this.no = no;
  }

  public String getStudentId() {
    return studentId;
  }

  public void setStudentId(String studentId) {
    this.studentId = studentId;
  }

  public String getCourseId() {
    return courseId;
  }

  public void setCourseId(String courseId) {
    this.courseId = courseId;
  }

  @Override
  public String toString() {
    return "Score{" +
            "id=" + id +
            ", username='" + username + '\'' +
            ", name='" + name + '\'' +
            ", scoreByUser='" + scoreByUser + '\'' +
            ", pointByUser='" + pointByUser + '\'' +
            ", creditsByUser='" + creditsByUser + '\'' +
            ", score=" + score +
            ", point=" + point +
            ", credits=" + credits +
            ", term=" + term +
            ", year=" + year +
            ", no='" + no + '\'' +
            ", studentId='" + studentId + '\'' +
            ", courseId='" + courseId + '\'' +
            '}';
  }
}
