package com.example.demoproj.util;

import com.example.demoproj.model.Course;
import javafx.util.StringConverter;

public class CourseStringConverter extends StringConverter<Course> {
    @Override
    public String toString(Course course) {
        return course == null ? null : course.name;
    }

    @Override
    public Course fromString(String s) {
        return null;
    }
}
