package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.Course;
import com.example.demoproj.model.User;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CourseController {

    @FXML
    private TableColumn<Course, Double> creditsColumn;

    @FXML
    private TableView<Course> dataTableView;

    @FXML
    private TableColumn<Course, String> idColumn;

    @FXML
    private TextField idTextField;

    @FXML
    private TableColumn<Course, String> nameColumn;

    @FXML
    private TextField nameTextField;

    @FXML
    private TableColumn<Course, Integer> numberColumn;

    @FXML
    private TableColumn<Course, String> professionColumn;

    @FXML
    private TableColumn<Course, Integer> scoreColumn;

    @FXML
    private TableColumn<Course, Integer> termColumn;

    @FXML
    private TableColumn<Course, String> typeColumn;

    public static List<Course> courseList;

    ObservableList<Course> obCourseList = FXCollections.observableArrayList();

    @FXML
    void onAddButtonClick(ActionEvent event) throws IOException {
        MainApplication.postView("addcourse.fxml");
    }

    @FXML
    void onChangeButtonClick(ActionEvent event) {
        String numName = idTextField.getText();

        if (numName == null || numName.equals("")) {
            try {
                MainApplication.postMessage("请输入课程序号");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                String[] ids = new String[1];
                ids[0] = numName;
                HttpRequestUtil.deleteCourse(ids);
                MainApplication.postView("addcourse.fxml");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    void onDeleteButtonClick(ActionEvent event) throws IOException {
        String numName = idTextField.getText();
        if (numName == null || numName.equals("")) {
            try {
                MainApplication.postMessage("请输入课程序号");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                String[] ids = new String[1];
                ids[0] = numName;
                HttpRequestUtil.deleteCourse(ids);
                MainApplication.postMessage("删除成功");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        MainApplication.changeView("main-frame.fxml");
    }

    @FXML
    void onQueryButtonClick(ActionEvent event) throws IOException {
        String realName = nameTextField.getText();

        Map<String,Object> m = new HashMap();
        m.put("code",realName);
        courseList = HttpRequestUtil.queryCourseList(m);
        MainApplication.postView("courseQuery.fxml");
    }
    @FXML
    public void onProfession(ActionEvent event) throws IOException {
        MainApplication.postView("professor.fxml");
    }
    public void loadData() throws Exception{
        List<Course> sList = HttpRequestUtil.getCourseList(17,0);
        obCourseList.clear();
        for (int i = 0; i < sList.size(); i++) {
            Course course = sList.get(i);

            // 处理每个course对象
            if (course.type == 0) {
                course.typeStr = "选修";
            } else {
                course.typeStr = "必修";
            }

            obCourseList.add(course);
        }
        dataTableView.setItems(obCourseList);
    }

    @FXML
    public void initialize() throws Exception{

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        professionColumn.setCellValueFactory(new PropertyValueFactory<>("profession"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        creditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));
        numberColumn.setCellValueFactory(new PropertyValueFactory<>("number"));
        termColumn.setCellValueFactory(new PropertyValueFactory<>("term"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("typeStr"));
        loadData();
    }
}
