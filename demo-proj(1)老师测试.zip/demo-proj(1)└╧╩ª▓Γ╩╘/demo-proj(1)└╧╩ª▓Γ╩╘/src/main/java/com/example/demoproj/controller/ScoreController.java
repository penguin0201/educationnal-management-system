package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.Score;
import com.example.demoproj.model.Score2;
import com.example.demoproj.model.User;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ScoreController {

    @FXML
    private TableColumn<Score2, String> courseIdColumn;

    @FXML
    private TableColumn<Score2, String> realNameColumn;

    @FXML
    private TableColumn<Score2, String> creditsColumn;

    @FXML
    private TableView<Score2> dataTableView;

    @FXML
    private TableColumn<Score2, String> nameColumn;

    @FXML
    private TableColumn<Score2, String> pointColumn;

    @FXML
    private TableColumn<Score2, Integer> scoreColumn;

    @FXML
    private TableColumn<Score2, String> studentIdColumn;

    @FXML
    private TextField studentIdTextField;

    @FXML
    private TextField studentNameTextField;

    @FXML
    private TableColumn<Score2, Integer> termColumn;
    public static List<Score> scoreList;

    ObservableList<Score2> obScoreList = FXCollections.observableArrayList();

    public static Map<String, String> students = new HashMap();

    public static Map<String, String> students2 = new HashMap();

    @FXML
    void onAddButtonClick(ActionEvent event) throws IOException {
        MainApplication.postView("addscore.fxml");
    }

    @FXML
    void onChangeButtonClick(ActionEvent event) {
        String numName;
        if (studentNameTextField.getText() != null && !studentNameTextField.getText().equals("")) {
            String s = studentNameTextField.getText();
            numName = students.get(s);
        } else {
            numName = studentIdTextField.getText();
        }

        if (numName == null || numName.equals("")) {
            try {
                MainApplication.postMessage("请输入学生信息");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                String[] ids = new String[1];
                ids[0] = numName;
                HttpRequestUtil.deleteScore(ids);
                MainApplication.postView("addscore.fxml");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    void onDeleteButtonClick(ActionEvent event) throws IOException {
        String numName;
        if (studentNameTextField.getText() != null && !studentNameTextField.getText().equals("")) {
            String s = studentNameTextField.getText();
            numName = students.get(s);
        } else {
            numName = studentIdTextField.getText();
        }

        if (numName == null || numName.equals("")) {
            try {
                MainApplication.postMessage("请输入学生信息");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                String[] ids = new String[1];
                ids[0] = numName;
                HttpRequestUtil.deleteScore(ids);
                MainApplication.postMessage("删除成功");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        MainApplication.changeView("main-frame.fxml");
    }

    @FXML
    void onQueryButtonClick(ActionEvent event) throws IOException {
        String numName;
        if (studentNameTextField.getText() != null && !studentNameTextField.getText().equals("")) {
            String s = studentNameTextField.getText();
            numName = students.get(s);
        } else {
            numName = studentIdTextField.getText();
        }

        Map<String, Object> map = new HashMap();
        map.put("code", numName);
        scoreList = HttpRequestUtil.queryScoreList(map);
        MainApplication.postView("scoreQuery.fxml");
    }

    public void loadData() throws Exception{
        List<Score> sList = HttpRequestUtil.getScoreList(17,0);
        obScoreList.clear();
        String realName ;
        for (int i = 0; i < sList.size(); i++) {
            Score score = sList.get(i);
            realName = students2.get(score.studentId);
            System.out.println(score.studentId);
            Score2 score2 = new Score2(score,realName);
//            System.out.println(score2);
            obScoreList.add(score2);
        }
        dataTableView.setItems(obScoreList);
    }

    @FXML
    public void initialize() throws Exception{
        courseIdColumn.setCellValueFactory(new PropertyValueFactory<>("courseId"));
        creditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        pointColumn.setCellValueFactory(new PropertyValueFactory<>("point"));
        scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));
        studentIdColumn.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        termColumn.setCellValueFactory(new PropertyValueFactory<>("term"));
        realNameColumn.setCellValueFactory(new PropertyValueFactory<>("realName"));
        List<User> userList = HttpRequestUtil.getStudentList(0,8020);
        for (int i = 0; i < userList.size(); i++) {
            User user = userList.get(i);
            students.put(user.realName,user.id);
            students2.put(user.id,user.realName);
            //System.out.println(user.realName);
        }
        System.out.println(students);
        System.out.println(students2);
        loadData();
    }
}
