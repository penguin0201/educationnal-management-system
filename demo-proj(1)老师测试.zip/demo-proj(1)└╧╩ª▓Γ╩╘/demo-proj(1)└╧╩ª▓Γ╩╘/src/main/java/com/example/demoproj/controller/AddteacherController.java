package com.example.demoproj.controller;

import com.example.demoproj.MainApplication;
import com.example.demoproj.model.User;
import com.example.demoproj.request.HttpRequestUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class AddteacherController implements Initializable {

    @FXML
    private TextField emailField;

    @FXML
    private TextField idField;

    @FXML
    private TextField passwordField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField schoolField;
    @FXML
    private TextField realNameField;

    @FXML
    private ChoiceBox<String> sexBox;
    private String[] gender = { "女", "男" };

    @FXML
    void onAddTeacher(ActionEvent event) throws IOException {
        Map<String,Object> map = new HashMap<>();
        map.put("id",idField.getText());
        map.put("realName",realNameField.getText());
        map.put("password",passwordField.getText());
        map.put("email",emailField.getText());
        map.put("phone",phoneField.getText());
        map.put("school",schoolField.getText());
        map.put("sex",getgender(event));
        User user = new User(map);
        HttpRequestUtil.addTeacher(user);
        MainApplication.changeView("main-frame.fxml");
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        sexBox.getItems().addAll(gender);
        sexBox.getSelectionModel().select(0);// TODO Auto-generated method stub
        sexBox.setOnAction(this::getgender);
        
    }

    private int getgender(ActionEvent actionEvent) {
        return sexBox.getSelectionModel().getSelectedIndex();
    }
}
